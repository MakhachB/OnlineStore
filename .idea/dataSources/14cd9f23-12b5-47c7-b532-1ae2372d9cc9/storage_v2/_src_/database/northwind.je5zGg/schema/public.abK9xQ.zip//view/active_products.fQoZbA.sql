create view active_products
            (product_id, product_name, supplier_id, category_id, quantity_per_unit, unit_price, units_in_stock,
             units_on_order, reorder_level, discontinued)
as
SELECT products.product_id,
       products.product_name,
       products.supplier_id,
       products.category_id,
       products.quantity_per_unit,
       products.unit_price,
       products.units_in_stock,
       products.units_on_order,
       products.reorder_level,
       products.discontinued
FROM products
WHERE products.discontinued <> 1
with local check option;

alter table active_products
    owner to postgres;

