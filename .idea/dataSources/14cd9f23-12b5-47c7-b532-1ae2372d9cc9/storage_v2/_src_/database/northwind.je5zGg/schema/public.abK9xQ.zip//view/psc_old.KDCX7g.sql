create view psc_old
            (product_name, quantity_per_unit, unit_price, units_in_stock, company_name, phone, category_name,
             description) as
SELECT products.product_name,
       products.quantity_per_unit,
       products.unit_price,
       products.units_in_stock,
       suppliers.company_name,
       suppliers.phone,
       categories.category_name,
       categories.description
FROM products
         JOIN suppliers USING (supplier_id)
         JOIN categories USING (category_id);

alter table psc_old
    owner to postgres;

