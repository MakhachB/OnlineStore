create view orders_custs_empls2
            (order_date, required_date, shipped_date, ship_postal_code, ship_country, company_name, contact_name, phone,
             last_name, first_name, title)
as
SELECT orders.order_date,
       orders.required_date,
       orders.shipped_date,
       orders.ship_postal_code,
       orders.ship_country,
       customers.company_name,
       customers.contact_name,
       customers.phone,
       employees.last_name,
       employees.first_name,
       employees.title
FROM orders
         JOIN customers USING (customer_id)
         JOIN employees USING (employee_id);

alter table orders_custs_empls2
    owner to postgres;

