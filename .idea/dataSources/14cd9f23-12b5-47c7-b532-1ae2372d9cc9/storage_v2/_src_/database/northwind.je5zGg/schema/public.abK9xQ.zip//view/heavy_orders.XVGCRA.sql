create view heavy_orders
            (order_id, customer_id, employee_id, order_date, required_date, shipped_date, ship_via, freight, ship_name,
             ship_address, ship_city, ship_region, ship_postal_code, ship_country)
as
SELECT orders.order_id,
       orders.customer_id,
       orders.employee_id,
       orders.order_date,
       orders.required_date,
       orders.shipped_date,
       orders.ship_via,
       orders.freight,
       orders.ship_name,
       orders.ship_address,
       orders.ship_city,
       orders.ship_region,
       orders.ship_postal_code,
       orders.ship_country
FROM orders
WHERE orders.freight > 100::double precision
with local check option;

alter table heavy_orders
    owner to postgres;

